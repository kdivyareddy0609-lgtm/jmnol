# Full code omitted for brevity, see documentation.
